import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Radio, 
  Facebook, 
  Instagram, 
  Youtube, 
  Twitter, 
  MessageCircle,
  Phone,
  Mail,
  MapPin,
  ShieldCheck
} from 'lucide-react';

const Footer = () => {
  const socialLinks = [
    { 
      icon: Facebook, 
      url: 'https://www.facebook.com/neri.araujo.9047',
      label: 'Facebook'
    },
    { 
      icon: Instagram, 
      url: 'https://www.instagram.com/propagandajotta',
      label: 'Instagram'
    },
    { 
      icon: Youtube, 
      url: 'https://www.youtube.com/channel/UCkjps0E3gCUkQ1LITC-wMFg',
      label: 'YouTube'
    },
    { 
      icon: Twitter, 
      url: 'https://x.com/jottaaraujo9',
      label: 'Twitter'
    },
    { 
      icon: MessageCircle, 
      url: 'https://wa.me/5549989199503',
      label: 'WhatsApp'
    }
  ];

  const quickLinks = [
    { name: 'Início', path: '/' },
    { name: 'Sobre Nós', path: '/sobre' },
    { name: 'Serviços', path: '/servicos' },
    { name: 'Projetos', path: '/projetos' },
    { name: 'Contato', path: '/contato' }
  ];

  return (
    <footer className="bg-gradient-to-br from-[#111111] via-[#1f7135] to-[#111111] text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo e Descrição */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="space-y-4"
          >
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#facc15] to-[#f59e0b] rounded-full flex items-center justify-center">
                <Radio className="w-7 h-7 text-white" />
              </div>
              <div>
                <span className="text-xl font-bold text-white">JOTTA ARAÚJO</span>
                <p className="text-sm text-gray-300 -mt-1">PRODUÇÕES</p>
              </div>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              Conectando empresários e ouvintes através da comunicação eficaz. 
              Sua voz, nossa missão!
            </p>
          </motion.div>

          {/* Links Rápidos */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="space-y-4"
          >
            <span className="text-lg font-semibold text-[#facc15]">Links Rápidos</span>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-gray-300 hover:text-[#facc15] transition-colors duration-200 text-sm"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Contato */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            <span className="text-lg font-semibold text-[#facc15]">Contato</span>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-[#facc15]" />
                <span className="text-gray-300 text-sm">(49) 98919-9503</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-[#facc15]" />
                <span className="text-gray-300 text-sm">araujojotta8@gmail.com</span>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="w-4 h-4 text-[#facc15] mt-0.5" />
                <span className="text-gray-300 text-sm">
                  R. Canasvieiras, 101 - Riviera, Cascavel - PR, 85814-816
                </span>
              </div>
            </div>
          </motion.div>

          {/* Redes Sociais */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="space-y-4"
          >
            <span className="text-lg font-semibold text-[#facc15]">Siga-nos</span>
            <div className="flex flex-wrap gap-3">
              {socialLinks.map((social) => {
                const IconComponent = social.icon;
                return (
                  <motion.a
                    key={social.label}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    className="w-10 h-10 bg-white/10 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-[#facc15] transition-all duration-300 group"
                  >
                    <IconComponent className="w-5 h-5 text-white group-hover:text-black transition-colors duration-300" />
                  </motion.a>
                );
              })}
            </div>
            <p className="text-gray-400 text-xs">
              Conecte-se conosco nas redes sociais para ficar por dentro de todas as novidades!
            </p>
          </motion.div>
        </div>

        {/* Linha divisória e Admin Link */}
        <div className="border-t border-white/20 mt-8 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-gray-400 text-sm text-center md:text-left">
              © 2025 Jotta Araújo Produções. Todos os direitos reservados.
            </p>
            <div className="flex items-center space-x-4 text-sm text-gray-400">
              <Link to="/admin/login" className="hover:text-[#facc15] transition-colors duration-200 flex items-center">
                <ShieldCheck className="w-4 h-4 mr-1" />
                Área do Administrador
              </Link>
              <span>•</span>
              <span>Desenvolvido com ❤️</span>
              <span>•</span>
              <span>Juka Produções</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;