import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Clock, MessageCircle, Facebook, Instagram, Youtube, Twitter } from 'lucide-react';

const ContactSidebar = () => {
  const socialLinks = [
    { 
      icon: Facebook, 
      url: 'https://www.facebook.com/neri.araujo.9047',
      label: 'Facebook',
      color: 'hover:bg-blue-600'
    },
    { 
      icon: Instagram, 
      url: 'https://www.instagram.com/propagandajotta',
      label: 'Instagram',
      color: 'hover:bg-pink-600'
    },
    { 
      icon: Youtube, 
      url: 'https://www.youtube.com/channel/UCkjps0E3gCUkQ1LITC-wMFg',
      label: 'YouTube',
      color: 'hover:bg-red-600'
    },
    { 
      icon: Twitter, 
      url: 'https://x.com/jottaaraujo9',
      label: 'Twitter',
      color: 'hover:bg-blue-400'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, x: 30 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      className="space-y-8"
    >
      {/* Business Hours */}
      <Card className="bg-gradient-to-br from-[#1f7135] to-[#2d8f47] text-white border-0">
        <CardContent className="p-6">
          <div className="flex items-center mb-4">
            <Clock className="w-6 h-6 mr-3" />
            <h3 className="text-xl font-bold">Horário de Atendimento</h3>
          </div>
          <div className="space-y-2 text-gray-200">
            <div className="flex justify-between">
              <span>Segunda a Sexta:</span>
              <span className="font-semibold">8h às 18h</span>
            </div>
            <div className="flex justify-between">
              <span>Sábado:</span>
              <span className="font-semibold">8h às 12h</span>
            </div>
            <div className="flex justify-between">
              <span>Domingo:</span>
              <span className="font-semibold">Fechado</span>
            </div>
          </div>
          <div className="mt-4 p-3 bg-white/10 rounded-lg backdrop-blur-sm">
            <p className="text-sm">
              📻 <strong>Rádio 24h:</strong> Nossa transmissão funciona 24 horas por dia, 7 dias por semana!
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Social Media */}
      <Card className="bg-white shadow-lg border-0">
        <CardContent className="p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">
            Siga-nos nas Redes Sociais
          </h3>
          <div className="grid grid-cols-2 gap-4">
            {socialLinks.map((social) => {
              const IconComponent = social.icon;
              return (
                <motion.a
                  key={social.label}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`flex items-center p-3 bg-gray-100 rounded-lg text-gray-700 hover:text-white transition-all duration-300 ${social.color}`}
                >
                  <IconComponent className="w-5 h-5 mr-3" />
                  <span className="font-medium">{social.label}</span>
                </motion.a>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Quick Contact */}
      <Card className="bg-[#facc15] border-0">
        <CardContent className="p-6 text-center">
          <h3 className="text-xl font-bold text-black mb-3">
            Precisa de Atendimento Rápido?
          </h3>
          <p className="text-gray-800 mb-4">
            Entre em contato pelo WhatsApp para respostas imediatas!
          </p>
          <Button
            asChild
            variant="primary_filled"
            className="font-semibold"
          >
            <a 
              href="https://wa.me/5549989199503"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center"
            >
              <MessageCircle className="w-5 h-5 mr-2" />
              Chamar no WhatsApp
            </a>
          </Button>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ContactSidebar;