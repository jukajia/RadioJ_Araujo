import React from 'react';
import { motion } from 'framer-motion';
import { Play, ExternalLink, Calendar, Users, Award } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const ProjectCard = ({ project, index, viewMode, categories, onPlayDemo, onViewDetails }) => {
  return (
    <motion.div
      key={project.id}
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ y: -5 }}
      className="relative"
    >
      {project.featured && (
        <div className="absolute -top-3 -right-3 bg-[#facc15] text-black px-3 py-1 rounded-full text-sm font-semibold z-10 flex items-center">
          <Award className="w-4 h-4 mr-1" />
          Destaque
        </div>
      )}

      <Card className={`h-full bg-white hover:shadow-2xl transition-all duration-300 border-0 shadow-lg overflow-hidden ${
        viewMode === 'list' ? 'flex flex-col sm:flex-row' : ''
      }`}>
        <div className={`relative ${viewMode === 'list' ? 'w-full sm:w-1/3' : 'w-full h-48'}`}>
          <img   
            alt={project.title}
            className="w-full h-full object-cover"
           src="https://images.unsplash.com/photo-1572177812156-58036aae439c" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          <div className="absolute top-4 left-4">
            <span className="bg-[#1f7135] text-white px-2 py-1 rounded-full text-xs font-medium">
              {categories.find(cat => cat.id === project.category)?.name}
            </span>
          </div>
          <div className="absolute bottom-4 right-4">
            <Button
              size="icon"
              variant="yellow_filled"
              onClick={() => onPlayDemo(project.title)}
              className="rounded-full w-10 h-10"
            >
              <Play className="w-5 h-5" />
            </Button>
          </div>
        </div>

        <CardContent className={`p-6 ${viewMode === 'list' ? 'flex-1' : ''}`}>
          <div className="flex items-start justify-between mb-3">
            <h3 className="text-xl font-bold text-gray-900 leading-tight">
              {project.title}
            </h3>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => onViewDetails(project.title)}
              className="text-[#1f7135] hover:bg-gray-100"
            >
              <ExternalLink className="w-4 h-4" />
            </Button>
          </div>

          <p className="text-gray-600 mb-4 leading-relaxed text-sm">
            {project.description}
          </p>

          <div className="space-y-2 mb-4">
            <div className="flex items-center text-xs text-gray-500">
              <Calendar className="w-3 h-3 mr-2" />
              {new Date(project.date).toLocaleDateString('pt-BR')}
            </div>
            <div className="flex items-center text-xs text-gray-500">
              <Users className="w-3 h-3 mr-2" />
              {project.client}
            </div>
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-gray-100 text-xs">
            <div>
              <span className="text-gray-500">Duração: </span>
              <span className="font-medium text-gray-900">{project.duration}</span>
            </div>
            <div>
              <span className="text-gray-500">Resultado: </span>
              <span className="font-medium text-[#1f7135]">{project.results}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ProjectCard;