import React from 'react';
import { Button } from '@/components/ui/button';
import { Filter, Grid, List } from 'lucide-react';

const ProjectFilters = ({ categories, activeFilter, onFilterChange, viewMode, onViewModeChange }) => {
  return (
    <section className="py-8 bg-gray-50 sticky top-16 z-40 border-b border-gray-200">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="flex flex-wrap gap-2 justify-center md:justify-start">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={activeFilter === category.id ? "primary_filled" : "outline"}
                onClick={() => onFilterChange(category.id)}
                size="sm"
                className="text-xs sm:text-sm"
              >
                <Filter className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                {category.name}
              </Button>
            ))}
          </div>

          <div className="flex items-center space-x-2">
            <Button
              variant={viewMode === 'grid' ? "primary_filled" : "outline"}
              size="icon"
              onClick={() => onViewModeChange('grid')}
              className="w-8 h-8 sm:w-10 sm:h-10"
            >
              <Grid className="w-3 h-3 sm:w-4 sm:h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? "primary_filled" : "outline"}
              size="icon"
              onClick={() => onViewModeChange('list')}
              className="w-8 h-8 sm:w-10 sm:h-10"
            >
              <List className="w-3 h-3 sm:w-4 sm:h-4" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProjectFilters;