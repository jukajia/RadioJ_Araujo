import React from 'react';
import { motion } from 'framer-motion';

const ProjectStats = () => {
  const stats = [
    { number: '500+', label: 'Projetos Realizados' },
    { number: '200+', label: 'Clientes Satisfeitos' },
    { number: '50+', label: 'Eventos Cobertos' },
    { number: '100%', label: 'Qualidade Garantida' }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="text-center"
            >
              <div className="text-3xl sm:text-4xl md:text-5xl font-bold text-[#1f7135] mb-2">
                {stat.number}
              </div>
              <div className="text-gray-600 font-medium text-sm sm:text-base">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectStats;