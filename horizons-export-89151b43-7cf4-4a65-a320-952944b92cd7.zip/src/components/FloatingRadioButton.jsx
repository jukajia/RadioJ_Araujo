import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Pause, Radio, Volume2, VolumeX, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const FloatingRadioButton = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const audioRef = useRef(null);

  const radioStreamUrl = 'http://212.84.160.3:5120/';
  const radioUrl = 'https://jottaaraujo.listen2myshow.com/';

  useEffect(() => {
    // Create audio element with direct stream URL
    audioRef.current = new Audio(radioStreamUrl);
    audioRef.current.crossOrigin = 'anonymous';
    audioRef.current.volume = volume;
    audioRef.current.preload = 'none';

    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);
    const onError = (e) => {
      console.error('Audio error:', e);
      setIsPlaying(false);
    };

    if (audioRef.current) {
      audioRef.current.addEventListener('play', onPlay);
      audioRef.current.addEventListener('pause', onPause);
      audioRef.current.addEventListener('error', onError);
    }

    return () => {
      if (audioRef.current) {
        audioRef.current.removeEventListener('play', onPlay);
        audioRef.current.removeEventListener('pause', onPause);
        audioRef.current.removeEventListener('error', onError);
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
      audioRef.current.muted = isMuted;
    }
  }, [volume, isMuted]);

  const togglePlay = async () => {
    try {
      if (!audioRef.current) return;

      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
        toast({
          title: "📻 Rádio pausada",
          description: "Transmissão interrompida"
        });
      } else {
        // Reset the audio source to ensure fresh connection
        audioRef.current.src = radioStreamUrl;
        await audioRef.current.play();
        toast({
          title: "🎧 Rádio tocando!",
          description: "Aproveite a programação ao vivo"
        });
      }
    } catch (error) {
      console.error("Erro na transmissão:", error);
      toast({
        title: "❌ Erro na transmissão",
        description: "Abrindo player externo...",
        variant: "destructive"
      });
      // Fallback to external player
      window.open(radioUrl, '_blank');
    }
  };

  const toggleMute = () => {
    if (audioRef.current) {
      audioRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  const handleVolumeChange = (newVolume) => {
    setVolume(newVolume);
    if (audioRef.current) {
      audioRef.current.volume = newVolume;
    }
  };

  return (
    <motion.div
      initial={{ scale: 0, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ delay: 1, type: "spring", stiffness: 260, damping: 20 }}
      className="fixed bottom-6 right-6 z-50"
    >
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.8 }}
            className="absolute bottom-16 right-0 bg-white/95 backdrop-blur-md rounded-2xl shadow-2xl border border-gray-200 p-4 min-w-[280px]"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-8 h-8 bg-gradient-to-br from-[#1f7135] to-[#2d8f47] rounded-full flex items-center justify-center">
                    <Radio className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-800 text-sm">Jotta Araújo</p>
                    <p className="text-xs text-gray-600">Rádio Ao Vivo</p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => window.open(radioUrl, '_blank')}
                  className="h-8 w-8"
                >
                  <ExternalLink className="w-4 h-4" />
                </Button>
              </div>

              <div className="flex items-center space-x-3">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={toggleMute}
                  className="h-8 w-8"
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </Button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={volume}
                  onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                  className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#1f7135]"
                />
              </div>

              <div className="text-center">
                <p className="text-xs text-gray-500">
                  🎵 Transmissão ao vivo 24h
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onHoverStart={() => setIsExpanded(true)}
        onHoverEnd={() => setIsExpanded(false)}
        className="relative"
      >
        <Button
          onClick={togglePlay}
          className="w-16 h-16 rounded-full bg-gradient-to-br from-[#1f7135] to-[#2d8f47] hover:from-[#2d8f47] hover:to-[#1f7135] shadow-2xl border-4 border-white/20 radio-waves"
        >
          <div className="flex flex-col items-center">
            {isPlaying ? (
              <Pause className="w-6 h-6 text-white" />
            ) : (
              <Play className="w-6 h-6 text-white ml-0.5" />
            )}
          </div>
        </Button>

        {/* Pulse animation for live indicator */}
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.7, 0.3, 0.7]
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full"
        />
        
        <div className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
          <div className="w-2 h-2 bg-white rounded-full" />
        </div>
      </motion.div>

      {/* Floating text */}
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 1.5 }}
        className="absolute right-20 top-1/2 transform -translate-y-1/2 bg-black/80 text-white px-3 py-1 rounded-full text-sm font-medium whitespace-nowrap pointer-events-none"
      >
        🎧 Ouça Agora
      </motion.div>
    </motion.div>
  );
};

export default FloatingRadioButton;