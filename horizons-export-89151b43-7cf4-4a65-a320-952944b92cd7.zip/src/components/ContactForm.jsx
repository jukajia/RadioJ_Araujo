import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { User, Mail, Phone, Building, Send } from 'lucide-react';

const ContactForm = ({ mailToEmail }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    company: '',
    service: '',
    message: ''
  });

  const services = [
    'Divulgação Comercial',
    'Produção de Vinhetas',
    'Entrevistas ao Vivo',
    'Programas Especiais',
    'Produção Audiovisual',
    'Locução Profissional',
    'Outro'
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.name || !formData.email || !formData.message) {
      toast({
        title: "❌ Campos obrigatórios",
        description: "Por favor, preencha nome, e-mail e mensagem."
      });
      return;
    }

    const subject = formData.service ? `Contato - ${formData.service}` : "Contato via Site";
    const body = `
      Nome: ${formData.name}
      Email: ${formData.email}
      Telefone: ${formData.phone || 'Não informado'}
      Empresa: ${formData.company || 'Não informada'}
      Serviço de Interesse: ${formData.service || 'Não especificado'}
      Mensagem:
      ${formData.message}
    `;

    const mailtoLink = `mailto:${mailToEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    
    window.location.href = mailtoLink;

    toast({
      title: "📬 Mensagem pronta para envio!",
      description: "Seu aplicativo de e-mail será aberto para você enviar a mensagem."
    });

    setFormData({
      name: '',
      email: '',
      phone: '',
      company: '',
      service: '',
      message: ''
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700 flex items-center">
            <User className="w-4 h-4 mr-2" />
            Nome *
          </label>
          <Input
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            placeholder="Seu nome completo"
            required
            className="border-gray-300 focus:border-[#1f7135] focus:ring-[#1f7135]"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700 flex items-center">
            <Mail className="w-4 h-4 mr-2" />
            E-mail *
          </label>
          <Input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleInputChange}
            placeholder="seu@email.com"
            required
            className="border-gray-300 focus:border-[#1f7135] focus:ring-[#1f7135]"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700 flex items-center">
            <Phone className="w-4 h-4 mr-2" />
            Telefone
          </label>
          <Input
            name="phone"
            value={formData.phone}
            onChange={handleInputChange}
            placeholder="(49) 98919-9503"
            className="border-gray-300 focus:border-[#1f7135] focus:ring-[#1f7135]"
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium text-gray-700 flex items-center">
            <Building className="w-4 h-4 mr-2" />
            Empresa
          </label>
          <Input
            name="company"
            value={formData.company}
            onChange={handleInputChange}
            placeholder="Nome da sua empresa"
            className="border-gray-300 focus:border-[#1f7135] focus:ring-[#1f7135]"
          />
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-gray-700">
          Serviço de Interesse
        </label>
        <select
          name="service"
          value={formData.service}
          onChange={handleInputChange}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#1f7135] focus:border-[#1f7135]"
        >
          <option value="">Selecione um serviço</option>
          {services.map((service) => (
            <option key={service} value={service}>
              {service}
            </option>
          ))}
        </select>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium text-gray-700">
          Mensagem *
        </label>
        <Textarea
          name="message"
          value={formData.message}
          onChange={handleInputChange}
          placeholder="Conte-nos sobre seu projeto ou necessidade..."
          rows={5}
          required
          className="border-gray-300 focus:border-[#1f7135] focus:ring-[#1f7135]"
        />
      </div>

      <Button
        type="submit"
        variant="primary_filled"
        className="w-full font-semibold py-3 text-lg"
      >
        <Send className="w-5 h-5 mr-2" />
        Enviar Mensagem
      </Button>
    </form>
  );
};

export default ContactForm;