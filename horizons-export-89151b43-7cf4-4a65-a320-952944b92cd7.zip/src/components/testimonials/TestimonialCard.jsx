import React from 'react';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const TestimonialCard = ({ testimonial, index }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1 }}
      whileHover={{ y: -5 }}
    >
      <Card className="h-full bg-white hover:shadow-2xl transition-all duration-300 border-0 shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex">
              {[...Array(testimonial.rating)].map((_, i) => (
                <Star key={i} className="w-4 h-4 text-[#facc15] fill-current" />
              ))}
            </div>
            {testimonial.featured && (
              <div className="bg-[#facc15] text-black px-2 py-1 rounded-full text-xs font-semibold">
                Destaque
              </div>
            )}
          </div>

          <blockquote className="text-gray-700 leading-relaxed mb-4 italic text-sm">
            "{testimonial.text.substring(0, 120)}..."
          </blockquote>

          <div className="border-t border-gray-100 pt-4">
            <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
            <p className="text-[#1f7135] text-sm font-medium">{testimonial.role}</p>
            <p className="text-gray-600 text-xs">{testimonial.business}</p>
            
            <div className="flex justify-between items-center mt-3 text-xs">
              <span className="text-[#1f7135] font-semibold">{testimonial.results}</span>
              <span className="text-gray-500">{testimonial.duration}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default TestimonialCard;