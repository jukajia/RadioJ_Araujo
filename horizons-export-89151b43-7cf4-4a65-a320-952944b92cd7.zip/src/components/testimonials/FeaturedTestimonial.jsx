import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote, Play, Award } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const FeaturedTestimonial = ({ testimonial, onPlayAudio, onContactClient }) => {
  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -100 }}
      transition={{ duration: 0.5 }}
      id={`testimonial-panel-${testimonial.id}`}
      role="tabpanel"
    >
      <Card className="bg-white shadow-2xl border-0 overflow-hidden">
        <CardContent className="p-0">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="relative h-64 lg:h-auto">
              <img   
                alt={`${testimonial.name} - ${testimonial.business}`}
                className="w-full h-full object-cover"
               src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              {testimonial.featured && (
                <div className="absolute top-4 left-4 bg-[#facc15] text-black px-3 py-1 rounded-full text-sm font-semibold flex items-center">
                  <Award className="w-4 h-4 mr-1" />
                  Cliente Destaque
                </div>
              )}
              <div className="absolute bottom-4 right-4">
                <Button
                  size="icon"
                  variant="yellow_filled"
                  onClick={() => onPlayAudio(testimonial.name)}
                  className="rounded-full w-12 h-12"
                  aria-label={`Ouvir depoimento de ${testimonial.name}`}
                >
                  <Play className="w-6 h-6" />
                </Button>
              </div>
            </div>

            <div className="p-8 lg:p-12">
              <div className="flex items-center mb-6">
                <Quote className="w-8 h-8 text-[#1f7135] mr-3" />
                <div className="flex" aria-label={`Avaliação: ${testimonial.rating} de 5 estrelas`}>
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-[#facc15] fill-current" aria-hidden="true" />
                  ))}
                </div>
              </div>

              <blockquote className="text-lg text-gray-700 leading-relaxed mb-6 italic">
                "{testimonial.text}"
              </blockquote>

              <div className="border-t border-gray-100 pt-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="text-xl font-bold text-gray-900">
                      {testimonial.name}
                    </h4>
                    <p className="text-[#1f7135] font-medium">
                      {testimonial.role}
                    </p>
                    <p className="text-gray-600 text-sm">
                      {testimonial.business}
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onContactClient(testimonial.name)}
                  >
                    Contatar
                  </Button>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">Resultado: </span>
                    <span className="font-semibold text-[#1f7135]">
                      {testimonial.results}
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">Parceria: </span>
                    <span className="font-semibold text-gray-900">
                      {testimonial.duration}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default FeaturedTestimonial;