import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';

const MapSection = ({ address, phone }) => {
  const [isMapVisible, setIsMapVisible] = useState(false);
  const mapEmbedUrl = `https://www.google.com/maps/embed/v1/place?key=YOUR_GOOGLE_MAPS_API_KEY&q=${encodeURIComponent(address)}`;
  // ^^^^ NOTE: User needs to replace YOUR_GOOGLE_MAPS_API_KEY with their actual Google Maps API Key for the embed to work.
  // For now, a placeholder visual will be shown.

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsMapVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    const mapElement = document.getElementById('map-container-element');
    if (mapElement) {
      observer.observe(mapElement);
    }

    return () => {
      if (mapElement) {
        observer.unobserve(mapElement);
      }
    };
  }, []);

  return (
    <section id="map-container-element" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Nossa <span className="gradient-text">Localização</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            {address}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="bg-white rounded-2xl shadow-2xl overflow-hidden h-[500px]"
        >
          {isMapVisible ? (
            <iframe
              src={`https://maps.google.com/maps?q=${encodeURIComponent(address)}&t=&z=15&ie=UTF8&iwloc=&output=embed`}
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen=""
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title={`Mapa de Localização - ${address}`}
            ></iframe>
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gray-200">
              <p className="text-gray-500">Carregando mapa...</p>
            </div>
          )}
        </motion.div>
         <div className="text-center mt-8">
            <Button
                asChild
                variant="primary_filled"
            >
                <a href={`tel:${phone}`}>
                    <Phone className="w-4 h-4 mr-2" />
                    Ligar Agora
                </a>
            </Button>
        </div>
      </div>
    </section>
  );
};

export default MapSection;