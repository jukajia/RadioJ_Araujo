import React, { useState, useEffect, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Radio, Play, Pause, Volume2, VolumeX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.5);
  const audioRef = useRef(null);
  const location = useLocation();

  const radioStreamUrl = 'http://212.84.160.3:5120/';

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    // Initialize audio element
    audioRef.current = new Audio(radioStreamUrl);
    audioRef.current.crossOrigin = 'anonymous';
    audioRef.current.volume = volume;
    audioRef.current.preload = 'none';

    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);
    const onError = (e) => {
      console.error('Audio error:', e);
      setIsPlaying(false);
    };

    if (audioRef.current) {
      audioRef.current.addEventListener('play', onPlay);
      audioRef.current.addEventListener('pause', onPause);
      audioRef.current.addEventListener('error', onError);
    }

    // Try autoplay after a delay
    const autoplayTimer = setTimeout(() => {
      if (audioRef.current) {
        audioRef.current.play().catch(() => {
          console.log('Autoplay bloqueado, use botão Ouça Agora.');
        });
      }
    }, 500);

    return () => {
      clearTimeout(autoplayTimer);
      if (audioRef.current) {
        audioRef.current.removeEventListener('play', onPlay);
        audioRef.current.removeEventListener('pause', onPause);
        audioRef.current.removeEventListener('error', onError);
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
      audioRef.current.muted = isMuted;
    }
  }, [volume, isMuted]);

  const handlePlayPause = async () => {
    if (!audioRef.current) return;
    
    try {
      if (isPlaying) {
        audioRef.current.pause();
        toast({
          title: "📻 Rádio pausada",
          description: "Transmissão interrompida"
        });
      } else {
        await audioRef.current.play();
        toast({
          title: "🎧 Rádio tocando!",
          description: "Aproveite a programação"
        });
      }
    } catch (error) {
      console.error("Erro ao tocar/pausar rádio:", error);
      toast({
        title: "❌ Erro na transmissão",
        description: "Não foi possível conectar à rádio. Verifique sua conexão.",
        variant: "destructive"
      });
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const navItems = [
    { name: 'Início', path: '/' },
    { name: 'Sobre Nós', path: '/sobre' },
    { name: 'Serviços', path: '/servicos' },
    { name: 'Projetos', path: '/projetos' },
    { name: 'Depoimentos', path: '/depoimentos' },
    { name: 'Contato', path: '/contato' },
    { name: 'Ao Vivo', path: '/ao-vivo' }
  ];

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-md shadow-lg border-b border-gray-200' 
          : 'bg-transparent'
      }`}
    >
      <nav className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-br from-[#1f7135] to-[#2d8f47] rounded-full flex items-center justify-center">
              <Radio className="w-6 h-6 text-white" />
            </div>
            <div className="hidden sm:flex items-center space-x-3">
              <div>
                <span className={`text-xl font-bold text-[#1f7135]`}>JOTTA ARAÚJO</span>
                <p className={`text-sm -mt-1 text-[#1f7135]`}>PRODUÇÕES</p>
              </div>
              
              {/* Mini Player */}
              <div className="hidden md:flex items-center space-x-2 bg-gray-900/90 backdrop-blur-sm rounded-lg px-3 py-2">
                <button
                  onClick={handlePlayPause}
                  className="w-6 h-6 bg-[#1f7135] rounded-full flex items-center justify-center hover:bg-[#2d8f47] transition-colors"
                  aria-label={isPlaying ? 'Pausar rádio' : 'Tocar rádio'}
                >
                  {isPlaying ? (
                    <Pause className="w-3 h-3 text-white" />
                  ) : (
                    <Play className="w-3 h-3 text-white ml-0.5" />
                  )}
                </button>
                
                <button
                  onClick={toggleMute}
                  className="text-white hover:text-[#facc15] transition-colors"
                  aria-label={isMuted ? 'Ativar som' : 'Silenciar'}
                >
                  {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </button>
                
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={volume}
                  onChange={(e) => setVolume(parseFloat(e.target.value))}
                  className="w-16 h-1 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-[#1f7135]"
                  disabled={isMuted}
                  aria-label="Controle de volume"
                />
                
                {isPlaying && (
                  <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" title="Ao vivo" />
                )}
              </div>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`relative font-medium transition-colors duration-200 text-[#1f7135] ${
                  location.pathname === item.path
                    ? 'text-[#1f7135]' 
                    : 'hover:text-[#facc15]'
                }`}
              >
                {item.name}
                {location.pathname === item.path && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute -bottom-1 left-0 right-0 h-0.5 bg-[#1f7135]"
                  />
                )}
              </Link>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className={`lg:hidden ${isScrolled || location.pathname !== '/' ? 'text-gray-700' : 'text-white'}`}
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden mt-4 bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden"
            >
              <div className="py-2">
                {navItems.map((item, index) => (
                  <motion.div
                    key={item.path}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Link
                      to={item.path}
                      className={`block px-4 py-3 font-medium transition-colors duration-200 text-[#1f7135] ${
                        location.pathname === item.path
                          ? 'bg-green-50'
                          : 'hover:bg-gray-50'
                      }`}
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {item.name}
                    </Link>
                  </motion.div>
                ))}
                
                {/* Mobile Player Controls */}
                <div className="px-4 py-3 border-t border-gray-200">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">Rádio Ao Vivo</span>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={handlePlayPause}
                        className="w-8 h-8 bg-[#1f7135] rounded-full flex items-center justify-center hover:bg-[#2d8f47] transition-colors"
                      >
                        {isPlaying ? (
                          <Pause className="w-4 h-4 text-white" />
                        ) : (
                          <Play className="w-4 h-4 text-white ml-0.5" />
                        )}
                      </button>
                      <button
                        onClick={toggleMute}
                        className="text-gray-600 hover:text-[#1f7135] transition-colors"
                      >
                        {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </motion.header>
  );
};

export default Header;