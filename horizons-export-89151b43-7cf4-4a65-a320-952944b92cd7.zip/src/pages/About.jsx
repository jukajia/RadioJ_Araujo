import React from 'react';
import { motion } from 'framer-motion';
import { 
  Target, 
  Heart, 
  Award, 
  Users, 
  Radio, 
  Mic,
  Star,
  CheckCircle
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const About = () => {
  const values = [
    {
      icon: Target,
      title: 'Missão',
      description: 'Conectar empresários e ouvintes através de uma comunicação eficaz e de qualidade, promovendo o crescimento dos negócios locais.'
    },
    {
      icon: Heart,
      title: 'Valores',
      description: 'Compromisso, qualidade, inovação e respeito ao nosso público. Acreditamos no poder da comunicação para transformar vidas.'
    },
    {
      icon: Award,
      title: 'Visão',
      description: 'Ser a principal referência em comunicação e divulgação na região, sempre inovando e superando expectativas.'
    }
  ];

  const achievements = [
    { icon: Users, number: '1000+', label: 'Clientes Satisfeitos' },
    { icon: Radio, number: '24h', label: 'Transmissão Diária' },
    { icon: Mic, number: '500+', label: 'Entrevistas Realizadas' },
    { icon: Star, number: '5+', label: 'Anos de Experiência' }
  ];

  const timeline = [
    {
      year: '2019',
      title: 'Início da Jornada',
      description: 'Fundação da Jotta Araújo Produções com foco em divulgação local'
    },
    {
      year: '2020',
      title: 'Expansão Digital',
      description: 'Lançamento da transmissão online 24 horas'
    },
    {
      year: '2021',
      title: 'Crescimento Regional',
      description: 'Ampliação do alcance para toda região oeste do Paraná'
    },
    {
      year: '2022',
      title: 'Inovação Tecnológica',
      description: 'Implementação de novas tecnologias de transmissão'
    },
    {
      year: '2024',
      title: 'Presente',
      description: 'Líder em comunicação regional com milhares de ouvintes diários'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 gradient-bg text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <div className="relative z-10 container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Sobre <span className="text-[#facc15]">Nós</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 leading-relaxed">
              Uma história de dedicação, inovação e compromisso com a comunicação de qualidade
            </p>
          </motion.div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                Nossa <span className="gradient-text">História</span>
              </h2>
              <div className="space-y-6 text-gray-600 leading-relaxed">
                <p className="text-lg">
                  A <strong className="text-[#1f7135]">Jotta Araújo Produções</strong> nasceu da paixão pela comunicação 
                  e do desejo de conectar pessoas e negócios através do poder da mídia radiofônica.
                </p>
                <p>
                  Desde nossa fundação, temos nos dedicado a oferecer soluções completas em comunicação, 
                  ajudando empresários locais a divulgarem seus negócios e alcançarem mais clientes através 
                  de nossa programação diversificada e de qualidade.
                </p>
                <p>
                  Com uma equipe apaixonada e comprometida, construímos uma base sólida de ouvintes fiéis 
                  que confiam em nosso conteúdo e serviços. Nossa missão vai além da simples transmissão: 
                  somos um elo vital na comunidade local.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <img  
                  alt="Estúdio de rádio moderno com equipamentos profissionais"
                  className="w-full h-96 object-cover"
                 src="https://images.unsplash.com/photo-1571576551636-2355d4fa0640" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <div className="absolute bottom-6 left-6 text-white">
                  <p className="text-lg font-semibold">Nosso Estúdio</p>
                  <p className="text-sm text-gray-200">Tecnologia de ponta para transmissão 24h</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Nossos <span className="gradient-text">Valores</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Os pilares que guiam nossa atuação e definem nossa identidade
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => {
              const IconComponent = value.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.2 }}
                  whileHover={{ y: -10 }}
                >
                  <Card className="h-full bg-white hover:shadow-2xl transition-all duration-300 border-0 shadow-lg">
                    <CardContent className="p-8 text-center">
                      <div className="w-16 h-16 bg-gradient-to-br from-[#1f7135] to-[#2d8f47] rounded-full flex items-center justify-center mx-auto mb-6">
                        <IconComponent className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-4">
                        {value.title}
                      </h3>
                      <p className="text-gray-600 leading-relaxed">
                        {value.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Nossos <span className="gradient-text">Números</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Resultados que demonstram nosso compromisso e dedicação
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => {
              const IconComponent = achievement.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.5 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1, type: "spring", stiffness: 260, damping: 20 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 bg-gradient-to-br from-[#1f7135] to-[#2d8f47] rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-3xl md:text-4xl font-bold text-[#1f7135] mb-2">
                    {achievement.number}
                  </div>
                  <div className="text-gray-600 font-medium text-sm">
                    {achievement.label}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Nossa <span className="gradient-text">Trajetória</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Marcos importantes que definiram nossa evolução
            </p>
          </motion.div>

          <div className="max-w-4xl mx-auto">
            {timeline.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -30 : 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                className={`flex items-center mb-12 ${
                  index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                }`}
              >
                <div className={`flex-1 ${index % 2 === 0 ? 'pr-8' : 'pl-8'}`}>
                  <Card className="bg-white shadow-lg border-0 hover:shadow-xl transition-all duration-300">
                    <CardContent className="p-6">
                      <div className="flex items-center mb-3">
                        <div className="w-12 h-12 bg-gradient-to-br from-[#1f7135] to-[#2d8f47] rounded-full flex items-center justify-center mr-4">
                          <CheckCircle className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <div className="text-2xl font-bold text-[#1f7135]">{item.year}</div>
                          <div className="text-lg font-semibold text-gray-900">{item.title}</div>
                        </div>
                      </div>
                      <p className="text-gray-600 leading-relaxed">{item.description}</p>
                    </CardContent>
                  </Card>
                </div>
                
                <div className="w-4 h-4 bg-[#facc15] rounded-full border-4 border-white shadow-lg z-10" />
                
                <div className="flex-1" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;