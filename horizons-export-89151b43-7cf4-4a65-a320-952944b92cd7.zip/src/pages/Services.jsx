import React from 'react';
import { motion } from 'framer-motion';
import { 
  Mic, 
  Radio, 
  Users, 
  Megaphone, 
  Music, 
  Video,
  Star,
  CheckCircle,
  ArrowRight,
  Clock,
  Shield,
  Zap
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const Services = () => {
  const mainServices = [
    {
      icon: Megaphone,
      title: 'Divulgação Comercial',
      description: 'Spots publicitários profissionais para promover seu negócio com alcance regional',
      features: [
        'Criação de spots personalizados',
        'Transmissão em horários estratégicos',
        'Alcance regional garantido',
        'Relatórios de audiência'
      ],
      price: 'A partir de R$ 150',
      highlight: true,
      whatsappText: "Olá! Gostaria de um orçamento para Divulgação Comercial."
    },
    {
      icon: Music,
      title: 'Produção de Vinhetas',
      description: 'Vinhetas exclusivas e profissionais para sua marca, evento ou programa',
      features: [
        'Vinhetas personalizadas',
        'Locução profissional',
        'Trilha sonora original',
        'Entrega em 48h'
      ],
      price: 'A partir de R$ 80',
      highlight: false,
      whatsappText: "Olá! Gostaria de um orçamento para Produção de Vinhetas."
    },
    {
      icon: Users,
      title: 'Entrevistas ao Vivo',
      description: 'Conecte-se diretamente com seu público através de entrevistas profissionais',
      features: [
        'Transmissão ao vivo',
        'Preparação de roteiro',
        'Divulgação prévia',
        'Gravação disponível'
      ],
      price: 'A partir de R$ 200',
      highlight: false,
      whatsappText: "Olá! Gostaria de um orçamento para Entrevistas ao Vivo."
    },
    {
      icon: Radio,
      title: 'Programas Especiais',
      description: 'Programas temáticos e especiais para datas comemorativas e eventos',
      features: [
        'Programação personalizada',
        'Cobertura de eventos',
        'Transmissão especial',
        'Interação com ouvintes'
      ],
      price: 'Sob consulta',
      highlight: false,
      whatsappText: "Olá! Gostaria de um orçamento para Programas Especiais."
    },
    {
      icon: Video,
      title: 'Produção Audiovisual',
      description: 'Conteúdo audiovisual para redes sociais e plataformas digitais',
      features: [
        'Vídeos promocionais',
        'Conteúdo para redes sociais',
        'Edição profissional',
        'Múltiplos formatos'
      ],
      price: 'A partir de R$ 300',
      highlight: false,
      whatsappText: "Olá! Gostaria de um orçamento para Produção Audiovisual."
    },
    {
      icon: Mic,
      title: 'Locução Profissional',
      description: 'Serviços de locução para diversos tipos de conteúdo e mídia',
      features: [
        'Locução comercial',
        'Narração institucional',
        'Dublagem',
        'Áudio de alta qualidade'
      ],
      price: 'A partir de R$ 100',
      highlight: false,
      whatsappText: "Olá! Gostaria de um orçamento para Locução Profissional."
    }
  ];

  const benefits = [
    {
      icon: Clock,
      title: 'Entrega Rápida',
      description: 'Prazos ágeis sem comprometer a qualidade'
    },
    {
      icon: Shield,
      title: 'Qualidade Garantida',
      description: 'Padrão profissional em todos os nossos serviços'
    },
    {
      icon: Zap,
      title: 'Alcance Regional',
      description: 'Cobertura em toda região oeste do Paraná'
    },
    {
      icon: Star,
      title: 'Atendimento Personalizado',
      description: 'Soluções sob medida para cada cliente'
    }
  ];

  const whatsappBaseUrl = "https://wa.me/5549989199503?text=";

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 gradient-bg text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <div className="relative z-10 container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Nossos <span className="text-[#facc15]">Serviços</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 leading-relaxed">
              Soluções completas em comunicação para impulsionar seu negócio
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              O que <span className="gradient-text">Oferecemos</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Serviços profissionais de comunicação com qualidade e alcance garantidos
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {mainServices.map((service, index) => {
              const IconComponent = service.icon;
              const whatsappLink = `${whatsappBaseUrl}${encodeURIComponent(service.whatsappText)}`;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -10 }}
                  className="relative"
                >
                  {service.highlight && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-[#facc15] text-black px-4 py-1 rounded-full text-sm font-semibold z-10">
                      Mais Popular
                    </div>
                  )}
                  
                  <Card className={`h-full transition-all duration-300 border-0 shadow-lg hover:shadow-2xl ${
                    service.highlight 
                      ? 'bg-gradient-to-br from-[#1f7135] to-[#2d8f47] text-white' 
                      : 'bg-white'
                  }`}>
                    <CardHeader className="text-center pb-4">
                      <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                        service.highlight 
                          ? 'bg-white/20 backdrop-blur-sm' 
                          : 'bg-gradient-to-br from-[#1f7135] to-[#2d8f47]'
                      }`}>
                        <IconComponent className={`w-8 h-8 ${
                          service.highlight ? 'text-white' : 'text-white'
                        }`} />
                      </div>
                      <CardTitle className={`text-xl mb-2 ${
                        service.highlight ? 'text-white' : 'text-gray-900'
                      }`}>
                        {service.title}
                      </CardTitle>
                      <p className={`text-sm leading-relaxed ${
                        service.highlight ? 'text-gray-200' : 'text-gray-600'
                      }`}>
                        {service.description}
                      </p>
                    </CardHeader>
                    
                    <CardContent className="pt-0">
                      <div className="space-y-3 mb-6">
                        {service.features.map((feature, featureIndex) => (
                          <div key={featureIndex} className="flex items-center space-x-2">
                            <CheckCircle className={`w-4 h-4 ${
                              service.highlight ? 'text-[#facc15]' : 'text-[#1f7135]'
                            }`} />
                            <span className={`text-sm ${
                              service.highlight ? 'text-gray-200' : 'text-gray-600'
                            }`}>
                              {feature}
                            </span>
                          </div>
                        ))}
                      </div>
                      
                      <div className="text-center">
                        <div className={`text-2xl font-bold mb-4 ${
                          service.highlight ? 'text-[#facc15]' : 'text-[#1f7135]'
                        }`}>
                          {service.price}
                        </div>
                        <Button
                          asChild
                          variant={service.highlight ? 'yellow_filled' : 'primary_filled'}
                          className="w-full"
                        >
                          <a href={whatsappLink} target="_blank" rel="noopener noreferrer">
                            Solicitar Orçamento
                          </a>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Por que <span className="gradient-text">Escolher</span> a Gente?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Diferenciais que fazem toda a diferença no seu resultado
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => {
              const IconComponent = benefit.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="w-16 h-16 bg-gradient-to-br from-[#1f7135] to-[#2d8f47] rounded-full flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2">
                    {benefit.title}
                  </h3>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {benefit.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Pronto para Começar?
            </h2>
            <p className="text-xl mb-8 text-gray-200">
              Entre em contato conosco e descubra como podemos ajudar seu negócio a crescer!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                asChild
                size="lg"
                variant="yellow_filled"
                className="font-semibold px-8 py-4 text-lg rounded-full"
              >
                <a href={`${whatsappBaseUrl}${encodeURIComponent("Olá! Gostaria de mais informações sobre seus serviços.")}`} target="_blank" rel="noopener noreferrer" className="flex items-center space-x-2">
                  <span>Fale Conosco</span>
                  <ArrowRight className="w-5 h-5" />
                </a>
              </Button>
              <Button
                asChild
                variant="white_outline"
                size="lg"
                className="font-semibold px-8 py-4 text-lg rounded-full"
              >
                <Link to="/projetos">Ver Projetos</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Services;