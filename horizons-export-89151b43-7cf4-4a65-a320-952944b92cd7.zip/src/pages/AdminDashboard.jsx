import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';
import { LayoutDashboard, Edit, Save, LogOut, Settings, Users, BarChart, Home as HomeIcon, Info, Briefcase, MessageSquare, Radio as RadioIcon, Image as ImageIcon, Mail as MailIcon, MapPin as MapPinIcon } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { db } from '@/lib/firebase';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { SortableItem } from '@/components/admin/SortableItem';
import { AdminSectionCard } from '@/components/admin/AdminSectionCard';

const AdminDashboard = () => {
  const { logout, user } = useAuth();
  const navigate = useNavigate();
  const [siteData, setSiteData] = useState({});
  const [editingSection, setEditingSection] = useState(null);
  const [formData, setFormData] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  // Define a default section order
  const defaultSectionOrder = [
    'homePage', 'aboutPage', 'servicesPage', 'projectsPage', 
    'testimonialsPage', 'livePage', 'contactPage', 'siteSettings'
  ];

  const [sectionOrder, setSectionOrder] = useState(defaultSectionOrder);

  const sectionsConfig = {
    homePage: { title: 'Página Inicial', icon: HomeIcon, fields: [
      { name: 'heroTitle', label: 'Título Principal', type: 'text' },
      { name: 'heroSubtitle', label: 'Subtítulo Principal', type: 'textarea' },
      { name: 'ctaButtonText', label: 'Texto Botão CTA', type: 'text' },
    ]},
    aboutPage: { title: 'Sobre Nós', icon: Info, fields: [
      { name: 'aboutTitle', label: 'Título Sobre', type: 'text' },
      { name: 'aboutText', label: 'Texto Sobre', type: 'textarea' },
    ]},
    servicesPage: { title: 'Serviços', icon: Briefcase, fields: [
      { name: 'servicesTitle', label: 'Título Serviços', type: 'text' },
      { name: 'servicesDescription', label: 'Descrição Serviços', type: 'textarea' },
    ]},
    projectsPage: { title: 'Projetos', icon: BarChart, fields: [
      { name: 'projectsTitle', label: 'Título Projetos', type: 'text' },
    ]},
    testimonialsPage: { title: 'Depoimentos', icon: MessageSquare, fields: [
      { name: 'testimonialsTitle', label: 'Título Depoimentos', type: 'text' },
    ]},
    livePage: { title: 'Ao Vivo', icon: RadioIcon, fields: [
      { name: 'liveTitle', label: 'Título Ao Vivo', type: 'text' },
      { name: 'radioStreamUrl', label: 'URL Stream Rádio', type: 'text' },
    ]},
    contactPage: { title: 'Contato', icon: MailIcon, fields: [
      { name: 'contactEmail', label: 'E-mail de Contato', type: 'email' },
      { name: 'contactPhone', label: 'Telefone de Contato', type: 'tel' },
      { name: 'contactAddress', label: 'Endereço', type: 'text' },
    ]},
    siteSettings: { title: 'Configurações Gerais', icon: Settings, fields: [
      { name: 'siteName', label: 'Nome do Site', type: 'text' },
      { name: 'logoUrl', label: 'URL da Logo', type: 'url' },
      { name: 'faviconUrl', label: 'URL do Favicon', type: 'url' },
    ]},
  };
  
  const orderedSectionsConfig = sectionOrder.map(id => ({ id, ...sectionsConfig[id] }));

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    try {
      const docRef = doc(db, "siteContent", "global");
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        setSiteData(data);
        if (data.sectionOrder) {
          // Filter out any IDs not present in current sectionsConfig
          const validOrder = data.sectionOrder.filter(id => sectionsConfig[id]);
          // Add any new sections from sectionsConfig not present in saved order
          const currentConfigIds = Object.keys(sectionsConfig);
          const newSections = currentConfigIds.filter(id => !validOrder.includes(id));
          setSectionOrder([...validOrder, ...newSections]);
        } else {
           setSectionOrder(defaultSectionOrder);
        }
      } else {
        const initialData = Object.keys(sectionsConfig).reduce((acc, sectionId) => {
          acc[sectionId] = sectionsConfig[sectionId].fields.reduce((fieldAcc, field) => {
            fieldAcc[field.name] = ''; // Initialize with empty strings
            return fieldAcc;
          }, {});
          return acc;
        }, {});
        initialData.sectionOrder = defaultSectionOrder;
        await setDoc(docRef, initialData);
        setSiteData(initialData);
        setSectionOrder(defaultSectionOrder);
      }
    } catch (error) {
      console.error("Erro ao buscar dados do site:", error);
      toast({ title: "Erro ao carregar dados", description: error.message, variant: "destructive" });
    } finally {
      setIsLoading(false);
    }
  }, []);


  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleLogout = async () => {
    try {
      await logout();
      toast({ title: "👋 Logout realizado", description: "Você foi desconectado com sucesso." });
      navigate('/admin/login');
    } catch (error) {
      toast({ title: "❌ Erro ao sair", description: "Não foi possível realizar o logout.", variant: "destructive" });
    }
  };

  const handleEditSection = (sectionId) => {
    setEditingSection(sectionId);
    setFormData(siteData[sectionId] || sectionsConfig[sectionId].fields.reduce((acc, field) => {
        acc[field.name] = ''; // Initialize with empty strings if no data
        return acc;
      }, {}));
  };

  const handleFormChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSaveSection = async () => {
    if (!editingSection) return;
    setIsSaving(true);
    try {
      const updatedSectionData = { ...siteData[editingSection], ...formData };
      const docRef = doc(db, "siteContent", "global");
      
      // Use updateDoc to only change the specific section and sectionOrder
      await updateDoc(docRef, {
        [editingSection]: updatedSectionData,
        sectionOrder: sectionOrder // Also save the current section order
      });

      setSiteData(prev => ({ ...prev, [editingSection]: updatedSectionData, sectionOrder }));
      toast({ title: "💾 Salvo!", description: `Seção ${sectionsConfig[editingSection]?.title} atualizada.` });
      setEditingSection(null);
    } catch (error) {
      console.error("Erro ao salvar seção:", error);
      toast({ title: "Erro ao salvar", description: error.message, variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleGlobalSave = async () => {
    setIsSaving(true);
    try {
      await setDoc(doc(db, "siteContent", "global"), { ...siteData, sectionOrder });
      toast({ title: "💾 Todas as alterações salvas!", description: "O conteúdo do site foi atualizado." });
    } catch (error) {
      console.error("Erro ao salvar dados globais:", error);
      toast({ title: "Erro ao salvar", description: error.message, variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  };
  
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  function handleDragEnd(event) {
    const {active, over} = event;
    if (active.id !== over.id) {
      setSectionOrder((items) => {
        const oldIndex = items.indexOf(active.id);
        const newIndex = items.indexOf(over.id);
        return arrayMove(items, oldIndex, newIndex);
      });
    }
  }


  if (isLoading && !Object.keys(siteData).length) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-16 h-16 border-4 border-[#1f7135] border-t-transparent rounded-full"
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 p-4 md:p-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <header className="mb-8 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center space-x-3 mb-4 md:mb-0">
            <LayoutDashboard className="w-8 h-8 text-[#1f7135]" />
            <h1 className="text-3xl font-bold text-gray-800">Painel do Administrador</h1>
          </div>
          <div className="flex items-center space-x-3">
            <Button onClick={handleGlobalSave} variant="primary_filled" disabled={isSaving}>
              <Save className="w-4 h-4 mr-2" />
              {isSaving ? 'Salvando...' : 'Salvar Todas Alterações'}
            </Button>
            <Button onClick={handleLogout} variant="outline">
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </Button>
          </div>
        </header>

        <p className="mb-6 text-gray-600">
          Bem-vindo(a), {user?.email || 'Administrador'}! Arraste os cards para reordenar as seções do site.
        </p>

        {editingSection ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="mb-6 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl flex items-center">
                  <Edit className="w-5 h-5 mr-2 text-[#1f7135]" />
                  Editando: {sectionsConfig[editingSection]?.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {sectionsConfig[editingSection]?.fields.map(field => (
                  <div key={field.name}>
                    <label htmlFor={field.name} className="block text-sm font-medium text-gray-700 mb-1">{field.label}</label>
                    {field.type === 'textarea' ? (
                      <Textarea
                        id={field.name}
                        name={field.name}
                        value={formData[field.name] || ''}
                        onChange={handleFormChange}
                        rows={3}
                        className="focus:border-[#1f7135] focus:ring-[#1f7135]"
                      />
                    ) : (
                      <Input
                        id={field.name}
                        name={field.name}
                        type={field.type}
                        value={formData[field.name] || ''}
                        onChange={handleFormChange}
                        className="focus:border-[#1f7135] focus:ring-[#1f7135]"
                      />
                    )}
                  </div>
                ))}
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setEditingSection(null)}>Cancelar</Button>
                  <Button onClick={handleSaveSection} disabled={isSaving}>
                    {isSaving ? 'Salvando...' : 'Salvar Seção'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
            <SortableContext items={sectionOrder} strategy={verticalListSortingStrategy}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {orderedSectionsConfig.map((sectionConfig) => (
                   <SortableItem key={sectionConfig.id} id={sectionConfig.id}>
                      <AdminSectionCard
                        sectionConfig={sectionConfig}
                        siteData={siteData}
                        onEditSection={handleEditSection}
                      />
                   </SortableItem>
                ))}
              </div>
            </SortableContext>
          </DndContext>
        )}
      </motion.div>
    </div>
  );
};

export default AdminDashboard;