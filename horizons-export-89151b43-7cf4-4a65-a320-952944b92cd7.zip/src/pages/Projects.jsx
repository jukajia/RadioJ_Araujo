import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, 
  ExternalLink, 
  Calendar, 
  Users, 
  Award,
  Filter,
  Grid,
  List
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import ProjectCard from '@/components/projects/ProjectCard';
import ProjectFilters from '@/components/projects/ProjectFilters';
import ProjectStats from '@/components/projects/ProjectStats';

const Projects = () => {
  const [filter, setFilter] = useState('todos');
  const [viewMode, setViewMode] = useState('grid');

  const categories = [
    { id: 'todos', name: 'Todos os Projetos' },
    { id: 'comercial', name: 'Divulgação Comercial' },
    { id: 'vinhetas', name: 'Vinhetas' },
    { id: 'entrevistas', name: 'Entrevistas' },
    { id: 'eventos', name: 'Eventos Especiais' }
  ];

  const projectsData = [
    {
      id: 1,
      title: 'Campanha Supermercado Central',
      category: 'comercial',
      description: 'Série de spots publicitários para promoção de ofertas especiais',
      image: 'Supermercado moderno com produtos em destaque e clientes fazendo compras',
      date: '2024-01-15',
      client: 'Supermercado Central',
      duration: '30 dias',
      results: '+40% vendas',
      featured: true
    },
    {
      id: 2,
      title: 'Vinheta Festa Junina 2024',
      category: 'vinhetas',
      description: 'Vinheta temática para programação especial de festa junina',
      image: 'Festa junina colorida com bandeirinhas, fogueira e pessoas dançando quadrilha',
      date: '2024-06-01',
      client: 'Programação Especial',
      duration: '1 mês',
      results: 'Sucesso total',
      featured: false
    },
    {
      id: 3,
      title: 'Entrevista Prefeito Municipal',
      category: 'entrevistas',
      description: 'Entrevista ao vivo sobre projetos municipais e desenvolvimento local',
      image: 'Estúdio de rádio com prefeito sendo entrevistado por jornalista',
      date: '2024-03-10',
      client: 'Prefeitura Municipal',
      duration: '45 min',
      results: '10k ouvintes',
      featured: true
    },
    {
      id: 4,
      title: 'Cobertura Feira do Empreendedor',
      category: 'eventos',
      description: 'Transmissão ao vivo e cobertura completa do evento',
      image: 'Feira de negócios com estandes, empresários e visitantes',
      date: '2024-02-20',
      client: 'SEBRAE',
      duration: '3 dias',
      results: 'Cobertura completa',
      featured: false
    },
    {
      id: 5,
      title: 'Campanha Loja de Roupas Fashion',
      category: 'comercial',
      description: 'Spots para lançamento de coleção de verão',
      image: 'Loja de roupas moderna com manequins e roupas da moda',
      date: '2024-04-05',
      client: 'Fashion Store',
      duration: '15 dias',
      results: '+60% vendas',
      featured: false
    },
    {
      id: 6,
      title: 'Vinhetas Natal 2023',
      category: 'vinhetas',
      description: 'Conjunto de vinhetas natalinas para programação especial',
      image: 'Decoração natalina com árvore, presentes e luzes coloridas',
      date: '2023-12-01',
      client: 'Programação Especial',
      duration: '1 mês',
      results: 'Audiência recorde',
      featured: true
    },
    {
      id: 7,
      title: 'Entrevista Empresário do Ano',
      category: 'entrevistas',
      description: 'Conversa com empresário premiado sobre sucesso nos negócios',
      image: 'Empresário bem-sucedido em escritório moderno durante entrevista',
      date: '2024-05-15',
      client: 'Associação Comercial',
      duration: '60 min',
      results: '15k ouvintes',
      featured: false
    },
    {
      id: 8,
      title: 'Festival de Música Local',
      category: 'eventos',
      description: 'Cobertura completa do festival com artistas regionais',
      image: 'Festival de música ao ar livre com palco, artistas e público',
      date: '2024-07-20',
      client: 'Prefeitura Cultural',
      duration: '2 dias',
      results: 'Transmissão ao vivo',
      featured: true
    }
  ];

  const filteredProjects = filter === 'todos' 
    ? projectsData 
    : projectsData.filter(project => project.category === filter);

  const handlePlayDemo = (projectTitle) => {
    toast({
      title: "🚧 Demo não disponível ainda",
      description: `Em breve você poderá ouvir o demo de "${projectTitle}"!`
    });
  };

  const handleViewDetails = (projectTitle) => {
    toast({
      title: "🚧 Detalhes em desenvolvimento",
      description: `Página de detalhes de "${projectTitle}" será disponibilizada em breve!`
    });
  };

  const whatsappLink = "https://wa.me/5549989199503?text=" + encodeURIComponent("Olá! Gostaria de iniciar um projeto.");

  return (
    <div className="min-h-screen">
      <section className="relative py-20 gradient-bg text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <div className="relative z-10 container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Nossos <span className="text-[#facc15]">Projetos</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 leading-relaxed">
              Conheça alguns dos trabalhos que realizamos com excelência e dedicação
            </p>
          </motion.div>
        </div>
      </section>

      <ProjectStats />

      <ProjectFilters 
        categories={categories} 
        activeFilter={filter} 
        onFilterChange={setFilter} 
        viewMode={viewMode}
        onViewModeChange={setViewMode}
      />

      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={filter + viewMode}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className={
                viewMode === 'grid' 
                  ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8'
                  : 'space-y-6'
              }
            >
              {filteredProjects.map((project, index) => (
                <ProjectCard 
                  key={project.id} 
                  project={project} 
                  index={index} 
                  viewMode={viewMode}
                  categories={categories}
                  onPlayDemo={handlePlayDemo}
                  onViewDetails={handleViewDetails}
                />
              ))}
            </motion.div>
          </AnimatePresence>

          {filteredProjects.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-12"
            >
              <div className="text-gray-400 text-lg">
                Nenhum projeto encontrado para esta categoria.
              </div>
            </motion.div>
          )}
        </div>
      </section>

      <section className="py-20 gradient-bg relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Seu Projeto Pode Ser o Próximo!
            </h2>
            <p className="text-xl mb-8 text-gray-200">
              Entre em contato conosco e vamos criar algo incrível juntos
            </p>
            <Button
              asChild
              size="lg"
              variant="yellow_filled"
              className="font-semibold px-8 py-4 text-lg rounded-full"
            >
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer">Iniciar Projeto</a>
            </Button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Projects;