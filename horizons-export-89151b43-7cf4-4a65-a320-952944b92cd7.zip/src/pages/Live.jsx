import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Radio, 
  Users, 
  Clock,
  ExternalLink,
  Heart,
  Share2,
  Download
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import LiveStats from '@/components/live/LiveStats';
import LiveSchedule from '@/components/live/LiveSchedule';
import LiveFeatures from '@/components/live/LiveFeatures';
import LivePlayer from '@/components/live/LivePlayer';

const Live = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const audioRef = useRef(null);

  const radioStreamUrl = 'http://212.84.160.3:5120/';
  const radioUrl = 'https://jottaaraujo.listen2myshow.com/';

  useEffect(() => {
    // Initialize audio with direct stream URL
    audioRef.current = new Audio(radioStreamUrl);
    audioRef.current.crossOrigin = 'anonymous';
    audioRef.current.volume = volume;
    audioRef.current.preload = 'none';
    
    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);
    const onError = (e) => {
      console.error('Audio error:', e);
      setIsPlaying(false);
    };
    const onVolumeChange = () => {
      if(audioRef.current) {
        setVolume(audioRef.current.volume);
        setIsMuted(audioRef.current.muted);
      }
    };

    if(audioRef.current) {
      audioRef.current.addEventListener('play', onPlay);
      audioRef.current.addEventListener('pause', onPause);
      audioRef.current.addEventListener('error', onError);
      audioRef.current.addEventListener('volumechange', onVolumeChange);
    }

    return () => {
      if (audioRef.current) {
        audioRef.current.removeEventListener('play', onPlay);
        audioRef.current.removeEventListener('pause', onPause);
        audioRef.current.removeEventListener('error', onError);
        audioRef.current.removeEventListener('volumechange', onVolumeChange);
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
      audioRef.current.muted = isMuted;
    }
  }, [volume, isMuted]);

  const handlePlayPause = async () => {
    if (!audioRef.current) return;
    
    try {
      if (isPlaying) {
        audioRef.current.pause();
        toast({
          title: "📻 Rádio pausada",
          description: "Transmissão interrompida"
        });
      } else {
        // Reset the audio source to ensure fresh connection
        audioRef.current.src = radioStreamUrl;
        await audioRef.current.play();
        toast({
          title: "🎧 Rádio tocando!",
          description: "Aproveite a programação ao vivo"
        });
      }
    } catch (error) {
      console.error("Erro ao tocar/pausar rádio:", error);
      toast({
        title: "❌ Erro na transmissão",
        description: "Não foi possível conectar à rádio. Tente abrir em uma nova aba.",
        variant: "destructive"
      });
      // Fallback to external player
      window.open(radioUrl, '_blank');
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Jotta Araújo Produções - Rádio Ao Vivo',
        text: 'Ouça agora a melhor programação da região!',
        url: window.location.href
      }).catch(error => console.log('Error sharing:', error));
    } else {
      navigator.clipboard.writeText(window.location.href).then(() => {
        toast({
          title: "🔗 Link copiado!",
          description: "Compartilhe com seus amigos"
        });
      }).catch(err => {
        console.error('Could not copy text: ', err);
        toast({
          title: "❌ Erro ao copiar",
          description: "Não foi possível copiar o link.",
          variant: "destructive"
        });
      });
    }
  };

  const handleDownloadApp = () => {
    toast({
      title: "🚧 Funcionalidade em desenvolvimento",
      description: "Em breve você poderá baixar nosso aplicativo!"
    });
  };

  return (
    <div className="min-h-screen">
      <LivePlayer
        isPlaying={isPlaying}
        isMuted={isMuted}
        volume={volume}
        radioUrl={radioUrl}
        onPlayPause={handlePlayPause}
        onMuteToggle={() => setIsMuted(!isMuted)}
        onVolumeChange={(newVolume) => setVolume(newVolume)}
        onShare={handleShare}
        onDownloadApp={handleDownloadApp}
      />
      <LiveStats />
      <LiveSchedule onPlayPause={handlePlayPause} />
      <LiveFeatures />
      <section className="py-20 gradient-bg relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Não Perca Mais Nenhum Programa!
            </h2>
            <p className="text-xl mb-8 text-gray-200">
              Salve nosso link e tenha acesso à melhor programação da região a qualquer hora
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={handlePlayPause}
                size="lg"
                variant="yellow_filled"
                className="font-semibold px-8 py-4 text-lg rounded-full"
              >
                <Play className="w-5 h-5 mr-2" />
                {isPlaying ? 'Pausar Rádio' : 'Ouvir Agora'}
              </Button>
              <Button
                onClick={handleDownloadApp}
                variant="live_button"
                size="lg"
                className="font-semibold px-8 py-4 text-lg rounded-full"
              >
                <Download className="w-5 h-5 mr-2" />
                Baixar App
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Live;