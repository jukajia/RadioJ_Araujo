import React from 'react';
import { motion } from 'framer-motion';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  MessageCircle,
  Send
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import ContactForm from '@/components/ContactForm'; 
import ContactInfoCards from '@/components/ContactInfoCards';
import ContactSidebar from '@/components/ContactSidebar';
import MapSection from '@/components/MapSection';

const Contact = () => {
  const contactInfo = [
    {
      icon: Phone,
      title: 'Telefone',
      info: '(49) 98919-9503',
      link: 'tel:+5549989199503',
      description: 'Ligue agora para falar conosco'
    },
    {
      icon: MessageCircle,
      title: 'WhatsApp',
      info: '(49) 98919-9503',
      link: 'https://wa.me/5549989199503',
      description: 'Envie uma mensagem pelo WhatsApp'
    },
    {
      icon: Mail,
      title: 'E-mail',
      info: 'araujojotta8@gmail.com',
      link: 'mailto:araujojotta8@gmail.com',
      description: 'Envie um e-mail para nós'
    },
    {
      icon: MapPin,
      title: 'Localização',
      info: 'R. Canasvieiras, 101 - Riviera, Cascavel - PR, 85814-816',
      link: 'https://www.google.com/maps/search/?api=1&query=R.+Canasvieiras,+101+-+riviera,+Cascavel+-+PR,+85814-816',
      description: 'Visite nosso endereço'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative py-20 gradient-bg text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <div className="relative z-10 container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Entre em <span className="text-[#facc15]">Contato</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 leading-relaxed">
              Estamos prontos para ajudar seu negócio a crescer. Fale conosco!
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Info Cards Section */}
      <ContactInfoCards contactInfo={contactInfo} />

      {/* Contact Form and Info Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <Card className="bg-white shadow-2xl border-0">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-gray-900 flex items-center">
                    <Send className="w-6 h-6 mr-3 text-[#1f7135]" />
                    Envie sua Mensagem
                  </CardTitle>
                  <p className="text-gray-600">
                    Preencha o formulário abaixo e entraremos em contato em breve
                  </p>
                </CardHeader>
                <CardContent>
                  <ContactForm mailToEmail="araujojotta8@gmail.com" />
                </CardContent>
              </Card>
            </motion.div>

            <ContactSidebar />
          </div>
        </div>
      </section>

      {/* Map Section */}
      <MapSection 
        address="R. Canasvieiras, 101 - Riviera, Cascavel - PR, 85814-816"
        phone="+5549989199503"
      />
    </div>
  );
};

export default Contact;