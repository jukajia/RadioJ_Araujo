import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Star, 
  Quote, 
  ChevronLeft, 
  ChevronRight,
  Play,
  Heart,
  Award,
  Users
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import TestimonialCard from '@/components/testimonials/TestimonialCard';
import FeaturedTestimonial from '@/components/testimonials/FeaturedTestimonial';
import TestimonialStats from '@/components/testimonials/TestimonialStats';

const Testimonials = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const testimonialsData = [
    {
      id: 1,
      name: 'Maria Silva',
      business: 'Padaria Doce Sabor',
      role: 'Proprietária',
      rating: 5,
      text: 'A Jotta Araújo Produções transformou completamente a divulgação da minha padaria. Em apenas um mês de spots na rádio, nossas vendas aumentaram 45%. O atendimento é excepcional e a qualidade dos spots é profissional.',
      image: 'Mulher sorridente proprietária de padaria em frente ao seu estabelecimento',
      results: '+45% vendas',
      duration: '3 meses',
      featured: true
    },
    {
      id: 2,
      name: 'João Santos',
      business: 'Auto Peças Central',
      role: 'Gerente Comercial',
      rating: 5,
      text: 'Trabalho com a equipe há mais de 2 anos. A dedicação e profissionalismo são impressionantes. Nossos clientes sempre comentam sobre os anúncios na rádio. Recomendo de olhos fechados!',
      image: 'Homem de negócios sorridente em loja de auto peças',
      results: '+60% clientes',
      duration: '2 anos',
      featured: false
    },
    {
      id: 3,
      name: 'Ana Costa',
      business: 'Clínica Bem Estar',
      role: 'Diretora',
      rating: 5,
      text: 'A entrevista que fizemos sobre saúde preventiva foi um sucesso absoluto. Recebemos centenas de ligações de novos pacientes. A equipe é muito preparada e profissional.',
      image: 'Médica profissional sorridente em clínica moderna',
      results: '200+ novos pacientes',
      duration: '6 meses',
      featured: true
    },
    {
      id: 4,
      name: 'Carlos Oliveira',
      business: 'Supermercado Família',
      role: 'Proprietário',
      rating: 5,
      text: 'As vinhetas personalizadas para nossas promoções são fantásticas! Cada campanha tem sua identidade única. O retorno do investimento é sempre positivo.',
      image: 'Empresário em supermercado moderno com produtos organizados',
      results: '+30% movimento',
      duration: '1 ano',
      featured: false
    },
    {
      id: 5,
      name: 'Luciana Ferreira',
      business: 'Escola Criança Feliz',
      role: 'Diretora Pedagógica',
      rating: 5,
      text: 'A cobertura dos nossos eventos escolares foi perfeita. As famílias ficaram emocionadas ao ouvir seus filhos na rádio. Parceria que vale muito a pena!',
      image: 'Diretora de escola sorridente com crianças ao fundo',
      results: '100% satisfação',
      duration: '8 meses',
      featured: false
    },
    {
      id: 6,
      name: 'Roberto Lima',
      business: 'Oficina do Roberto',
      role: 'Mecânico',
      rating: 5,
      text: 'Sou cliente há 3 anos e posso garantir: a Jotta Araújo é sinônimo de qualidade. Minha oficina ficou conhecida na cidade toda graças aos spots na rádio.',
      image: 'Mecânico sorridente em oficina bem equipada',
      results: '+80% clientes',
      duration: '3 anos',
      featured: true
    }
  ];

  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonialsData.length);
  };

  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonialsData.length) % testimonialsData.length);
  };

  const handlePlayAudio = (clientName) => {
    toast({
      title: "🚧 Áudio não disponível ainda",
      description: `Em breve você poderá ouvir o depoimento de ${clientName}!`
    });
  };

  const handleContactClient = (clientName) => {
    toast({
      title: "🚧 Contato em desenvolvimento",
      description: `Funcionalidade de contato com ${clientName} será disponibilizada em breve!`
    });
  };

  const whatsappLink = "https://wa.me/5549989199503?text=" + encodeURIComponent("Olá! Gostaria de saber mais sobre seus casos de sucesso.");

  return (
    <div className="min-h-screen">
      <section className="relative py-20 gradient-bg text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <div className="relative z-10 container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-4xl mx-auto"
          >
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              <span className="text-[#facc15]">Depoimentos</span> dos Clientes
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 leading-relaxed">
              Veja o que nossos clientes falam sobre nossos serviços e resultados
            </p>
          </motion.div>
        </div>
      </section>

      <TestimonialStats />

      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Histórias de <span className="gradient-text">Sucesso</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Cada cliente tem uma história única de crescimento e sucesso
            </p>
          </motion.div>

          <div className="relative max-w-4xl mx-auto">
            <AnimatePresence mode="wait">
              <FeaturedTestimonial 
                key={currentTestimonial}
                testimonial={testimonialsData[currentTestimonial]}
                onPlayAudio={handlePlayAudio}
                onContactClient={handleContactClient}
              />
            </AnimatePresence>
            
            <div className="flex justify-center items-center mt-8 space-x-4">
              <Button
                variant="outline"
                size="icon"
                onClick={prevTestimonial}
                className="rounded-full"
                aria-label="Depoimento Anterior"
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>

              <div className="flex space-x-2" role="tablist" aria-label="Navegação de depoimentos">
                {testimonialsData.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentTestimonial(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === currentTestimonial 
                        ? 'bg-[#1f7135] w-8' 
                        : 'bg-gray-300 hover:bg-gray-400'
                    }`}
                    role="tab"
                    aria-selected={index === currentTestimonial}
                    aria-controls={`testimonial-panel-${index}`}
                    aria-label={`Ver depoimento ${index + 1}`}
                  />
                ))}
              </div>

              <Button
                variant="outline"
                size="icon"
                onClick={nextTestimonial}
                className="rounded-full"
                aria-label="Próximo Depoimento"
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Todos os <span className="gradient-text">Depoimentos</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Veja o que mais clientes falam sobre nossos serviços
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonialsData.map((testimonial, index) => (
              <TestimonialCard key={testimonial.id} testimonial={testimonial} index={index} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 gradient-bg relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20" />
        <div className="relative z-10 container mx-auto px-4 text-center text-white">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-3xl mx-auto"
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Seja Nosso Próximo Caso de Sucesso!
            </h2>
            <p className="text-xl mb-8 text-gray-200">
              Junte-se aos nossos clientes satisfeitos e veja seu negócio crescer
            </p>
            <Button
              asChild
              size="lg"
              variant="yellow_filled"
              className="font-semibold px-8 py-4 text-lg rounded-full"
            >
              <a href={whatsappLink} target="_blank" rel="noopener noreferrer">Começar Agora</a>
            </Button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Testimonials;